SISMOS 

Se muestran visualizaciones relacionadas con el tema de sismos en M�xico. 
Las visualizaciones estan disponibles en: http://humbertomg.com/sismos/

Getting Started: 
1. Descargar archivo datos_abiertos_sismos.zip ubicado en secci�n Datos y c�digo abierto disponible en http://humbertomg.com/sismos/index.html
2. Instalar paquete estad�stico R disponible en https://cran.r-project.org/
3. Instalar y registrarse en Tableu, programa de visualizaci�n con licencia de prueba de 14 d�as disponible en				https://www.tableau.com/products/trial
4. Instalar paquete estad�stico STATA, programa con pago disponible en https://www.stata.com/statamp/

Visualizaci�n 1 (Sismos en M�xico 1900-2017, de magnitud igual o mayor a 4.2)
1. Abir archivo mexmax.rar
2. Descomprimir la carpeta 
3. Abrir archivo app.R
4. Correr el c�digo

Visualizaci�n 2 (Cantidad de sismos anualmente en M�xico, 1980-2017)
1. Abrir archivo estadisticas_graph_mex_sismos.rar
2. Descomprimir la carpeta 
3. Abrir archivo graph_mex_sismos_estadisticas.R
3. Establecer el setwd a la ruta donde se descomprimi� la carpeta estadisticas_graph_mex_sismos.rar
4. Establecer root a la ruta donde se descomprimi� la carpeta estadisticas_graph_mex_sismos.rar
5. Correr el c�digo 

Visualizaci�n 3 (Sismos totales por estado, 1900-2017)
1. Abrir archivo maps_mex_sismos_estados_magnitud_tableau.rar
2. Descomprimir la carpeta 
3. Abrir archivo maps_mex_sismos_estados_magnitud_tableau.twb donde se encuentran las visualizaciones

Visualizaci�n 4 (Materiales de las viviendas de los estados m�s afectados por los sismos, 1900-2017)
1. Abrir archivo maps_mex_materiales_vivienda_tableau.rar
2. Descomprimir la carpeta 
3. Abrir archivo materiales-de-vivienda.twb donde se encuentran las visualizaciones

Visualizaci�n 5 (Mapa de intensidad - Sismo 19s 1985)
1. Abrir archivo mapa19s85.rar
2. Descomprimir la carpeta 
3. Abrir archivo app.R
4. Correr el c�digo

Visualizaci�n 6 (Mapa de aceleraci�n - Sismo 7s 2017)
1. Abrir archivo mapa7s17.rar
2. Descomprimir la carpeta 
3. Abrir archivo app.R
4. Correr el c�digo

Visualizaci�n 7 (Mapa de aceleraci�n - Sismo 19s 2017)
1. Abrir archivo mapa19s17.rar
2. Descomprimir la carpeta 
3. Abrir archivo app.R
4. Correr el c�digo

Visualizaci�n 8 (Municipios con declaratoria de emergencia)
1. Abrir archivo maps_mex_declaratoria_emergencia_tableau.rar
2. Descomprimir la carpeta 
3. Abrir archivo declaratoria_emergencia.twb donde se encuentran las visualizaciones

Visualizaci�n 9 (Montos y usos de los apoyos federales)
1. Abrir archivo maps_mex_apoyos_fonden_tableau.rar
2. Descomprimir la carpeta 
3. Abrir archivo Apoyos - Fonden.twb donde se encuentran las visualizaciones

Visualizaci�n 10 (Viviendas y municipios afectados por el sismo del 7 de septiembre)
1. Abrir archivo maps_mex_viviendas_afectadas_tableau.rar
2. Descomprimir la carpeta 
3. Abrir archivo maps_mex_inmuebles.twb donde se encuentran las visualizaciones

Visualizaci�n 11 (Derrumbres y muertes)
1. Abrir archivo maps_mex_dermue_tableau.rar
2. Descomprimir la carpeta 
3. Abrir archivo maps_mex_dermue.twb donde se encuentran las visualizaciones

Visualizaci�n 12 (Inmuebles revisados)
1. Abrir archivo maps_mex_dermue_tableau.rar
2. Descomprimir la carpeta 
3. Abrir archivo maps_mex_inmuebles.twb donde se encuentran las visualizaciones

Visualizaci�n 13 (Relaci�n entre Indicadores de Bienestar y Sismos en M�xico)
1. Abrir archivo indicadores de bienestar y sismos en M�xico.rar
2. Descomprimir la carpeta 
3. Abrir archivo maps_mex_inmuebles.twb donde se encuentran las visualizaciones

Tablas correlaciones 
1. Abrir archivo correlaciones.rar
2. Descomprimir la carpeta 
3. Abrir archivo script_union.do 
4. Cambiar raiz a globales y cd
5. Correr el c�digo 

Limpieza de bases de datos utilizadas
1. Abir archivo Replicacion_Sismos.rar
2. Descomprimir la carpeta 
3. Abrir carpeta Programas
4. Abrir CDMX19s.do 
5. Cambiar raiz a globales y cd 
6. Correr el c�digo 
7. Abrir censo_2015_estados_principales
8. Cambiar raiz a globales y cd 
9. Correr el c�digo
10. Abrir Limpieza BD_Gobierno
11. Cambiar raiz a globales y cd
12. Correr c�digo

Autores: Jes�s Martin, Humberto Martinez, Alexis Rodas, Eva Gonz�lez 








 